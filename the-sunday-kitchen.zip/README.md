# The Sunday Kitchen — Culinary Studio

A responsive Flask website for a fictional culinary learning studio. Fees, schedules, instructors, location and contact details are illustrative placeholders only.

## Features

- Home, workshop listing/details, course listing/outlines, studio, journal and contact pages.
- Responsive editorial styling, mobile navigation and reduced-motion support.
- Booking-enquiry and contact forms with server-side validation and CSRF protection.
- SQLite persistence via the standard library `sqlite3` module.
- Security headers (CSP, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy).
- Request-size limit (16 KiB), parameterized SQL, Jinja2 autoescaping and 23 automated tests.

## Requirements

- **Python 3.8+** (3.10+ recommended)
- Packages: Flask, Flask-WTF, pytest, bandit (see `requirements.txt`)

## Run locally

```bash
# 1. Create a virtual environment
python3 -m venv .venv

# 2. Activate it
source .venv/bin/activate         # macOS / Linux
# .venv\Scripts\activate          # Windows

# 3. Install dependencies
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

# 4. Set a secret key and start
export SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
export APP_ENV=development
python app.py
```

Open **http://127.0.0.1:5000**. The database is created at `instance/sunday_kitchen.sqlite3`.  
Set `DATABASE_PATH` to choose another file location.

If `SECRET_KEY` is unset in development, a temporary process-local key is generated (a warning is logged). In production mode (`APP_ENV=production`), startup raises an error unless `SECRET_KEY` is set. Configure `SESSION_COOKIE_SECURE=1` only when serving over HTTPS.

## Test and audit

```bash
# Run all 23 automated tests
python -m pytest tests/test_app.py -v

# Static analysis — production source, medium+ severity (exit 0 = no issues)
python -m bandit -r app.py catalog.py -ll -f txt

# Static analysis — all severities (B101 assert_used in tests/ is expected/correct)
python -m bandit -r app.py catalog.py tests/ -f txt
```

See `reports/audit-scope.md`, `reports/findings.md` and `reports/remediation-report.md` for the full security review. Passing tests or Bandit at medium+ severity does not guarantee the application is free of all risk.

## Project structure

```
.
├── app.py              # Flask application (routes, validation, DB, headers)
├── catalog.py          # Static catalogue data (workshops, courses, journal)
├── requirements.txt    # Dependency version bounds
├── .env.example        # Environment variable template
├── .gitignore          # Excludes .venv, .env, instance/*.sqlite3
├── templates/          # Jinja2 HTML templates (base, index, workshops, etc.)
├── static/
│   ├── css/styles.css  # Stylesheet
│   └── js/main.js      # Mobile menu toggle
├── tests/
│   └── test_app.py     # 23 functional and security-control tests
├── reports/
│   ├── audit-scope.md          # Review scope, methods, commands, limitations
│   ├── findings.md             # Confirmed findings and potential concerns
│   └── remediation-report.md  # Actions taken, tool output, verification status
└── instance/           # Generated at runtime; contains SQLite database (Git-ignored)
```

## Security notes

- All SQL uses parameterized queries (`?` placeholders); no string-format SQL.
- Workshop slugs and session identifiers are validated against an allowlist before database writes.
- CSRF tokens are required on all POST requests via Flask-WTF.
- Server-side validation enforces length limits, email format and control-character rejection.
- Response headers include a restrictive CSP (`script-src 'self'` — no `unsafe-inline`).

## Before a real launch

Replace all placeholder content and contacts. Review Unsplash image licences and Google Fonts privacy policy; consider self-hosting assets. Set production secrets, HTTPS and cookie flags. Establish rate limiting, logging, backups, data-retention and deletion policies. Complete independent penetration testing. Add authentication if an admin interface or enquiry browser is required.

Authentication, admin interface, email delivery, payments and real booking confirmations are not included.
